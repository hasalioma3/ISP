import streamlit as st
import subprocess
import os
import secrets
import string
import time
import psycopg2
from psycopg2 import sql
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

# Configuration
BASE_PORT = 8001
HOST_IP = "192.168.88.11"
DB_HOST = "192.168.88.11" # Targeting the host DB from inside container? No, usually host.docker.internal or gateway
# For simplicity, we'll assume this app runs on the host or we figure out networking. 
# Let's assume this app runs directly on the Pi for now, or in a container with net=host.

st.set_page_config(page_title="ISP Tenant Manager", layout="wide")

st.title("ISP Billing - Tenant Manager")

def get_db_connection():
    conn = psycopg2.connect(
        host="localhost", # Assumes running on host network
        database="postgres",
        user="isp_user",
        password="isp_password"
    )
    conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
    return conn

def create_tenant_db(company_name):
    # Sanitize name
    safe_name = "".join(c for c in company_name if c.isalnum()).lower()
    db_name = f"isp_{safe_name}"
    user_name = f"user_{safe_name}"
    password = ''.join(secrets.choice(string.ascii_letters + string.digits) for i in range(16))
    
    conn = get_db_connection()
    cur = conn.cursor()
    
    try:
        # Create User
        cur.execute(sql.SQL("CREATE USER {} WITH PASSWORD %s").format(sql.Identifier(user_name)), [password])
    except psycopg2.errors.DuplicateObject:
        pass # User exists
        
    try:
        # Create Database
        cur.execute(sql.SQL("CREATE DATABASE {} OWNER {}").format(sql.Identifier(db_name), sql.Identifier(user_name)))
    except psycopg2.errors.DuplicateDatabase:
        return None, None, None, "Database already exists"
    
    cur.close()
    conn.close()
    
    return db_name, user_name, password, None

def deploy_container(company_name, port, db_name, db_user, db_pass):
    safe_name = "".join(c for c in company_name if c.isalnum()).lower()
    container_name = f"isp-{safe_name}"
    
    # Docker Run Command
    # We mount the docker socket to allow managing other containers? No, we just run this command on the host.
    # Note: This Python script is intended to run on the HOST or a privileged container.
    
    cmd = [
        "docker", "run", "-d",
        "--name", container_name,
        "-p", f"{port}:8000",
        "--restart", "always",
        "-e", f"DATABASE_URL=postgresql://{db_user}:{db_pass}@172.17.0.1:5432/{db_name}", # 172.17.0.1 is usually docker host
        "-e", "CELERY_BROKER_URL=redis://172.17.0.1:6379/1",
        "-e", "CELERY_RESULT_BACKEND=redis://172.17.0.1:6379/1",
        "-e", f"SERVER_IP={HOST_IP}",
        "-e", f"ALLOWED_HOSTS={HOST_IP},localhost,127.0.0.1",
        "-e", f"CSRF_TRUSTED_ORIGINS=http://{HOST_IP}:{port}",
        "isp_core:latest"
    ]
    
    try:
        result = subprocess.run(cmd, check=True, capture_output=True, text=True)
        return True, result.stdout
    except subprocess.CalledProcessError as e:
        return False, e.stderr

# UI
with st.form("deploy_form"):
    company_name = st.text_input("Company Name")
    submit = st.form_submit_button("Deploy New Customer")
    
if submit and company_name:
    st.info(f"Deploying for {company_name}...")
    
    # 1. Database
    db_name, db_user, db_pass, error = create_tenant_db(company_name)
    if error:
        st.error(f"Database Error: {error}")
    else:
        st.success(f"Database {db_name} created!")
        
        # 2. Port Allocation (Naive)
        # In production, check used ports.
        # For valid demo, we hash the name to a port or increment. 
        # Using timestamp for now to avoid collision in simple test
        port = 8000 + (hash(company_name) % 1000) 
        if port < 8000: port += 1000
        
        # 3. Deploy
        success, msg = deploy_container(company_name, port, db_name, db_user, db_pass)
        
        if success:
            st.success(f"Deployed successfully on Port {port}!")
            st.code(f"URL: http://{HOST_IP}:{port}\nDB: {db_name}\nUser: {db_user}\nPass: {db_pass}")
        else:
            st.error(f"Docker Error: {msg}")

st.header("Active Tenants")
# Check running containers
try:
    res = subprocess.run(["docker", "ps", "--format", "table {{.Names}}\t{{.Ports}}\t{{.Status}}"], capture_output=True, text=True)
    st.text(res.stdout)
except Exception:
    st.error("Could not list containers")
